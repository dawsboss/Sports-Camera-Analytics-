%TF.GenerationSoftware,KiCad,Pcbnew,9.0.9-9.0.9~ubuntu24.04.1*%
%TF.CreationDate,2026-09-26T21:35:48+00:00*%
%TF.ProjectId,sideline-cam-hub,73696465-6c69-46e6-952d-63616d2d6875,rev?*%
%TF.SameCoordinates,Original*%
%TF.FileFunction,Soldermask,Top*%
%TF.FilePolarity,Negative*%
%FSLAX46Y46*%
G04 Gerber Fmt 4.6, Leading zero omitted, Abs format (unit mm)*
G04 Created by KiCad (PCBNEW 9.0.9-9.0.9~ubuntu24.04.1) date 2026-09-26 21:35:48*
%MOMM*%
%LPD*%
G01*
G04 APERTURE LIST*
%ADD10C,2.200000*%
G04 APERTURE END LIST*
D10*
%TO.C,H2*%
X144500000Y-141000000D03*
%TD*%
%TO.C,H1*%
X108250000Y-111900000D03*
%TD*%
%TO.C,H3*%
X169350000Y-117900000D03*
%TD*%
M02*
